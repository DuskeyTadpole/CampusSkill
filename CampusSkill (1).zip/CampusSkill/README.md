
# CampusSkill - Skill Exchange Platform for Students

CampusSkill is a web-based project built using Flask. It enables students of a college to exchange skills with one another — like video editing, programming help, graphic design, etc.

## Features
- Submit your name, skill, and contact
- View other students' skills
- Simple and easy to use UI

## Tech Stack
- Python + Flask
- HTML/CSS
- Render.com for deployment

## How to Run Locally
```bash
pip install -r requirements.txt
python app/app.py
```

## Deployment
Deployed using [Render](https://render.com/). Uses `gunicorn` and `render.yaml`.

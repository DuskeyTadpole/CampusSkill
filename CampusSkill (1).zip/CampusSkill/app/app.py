
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

skills = []

@app.route('/')
def index():
    return render_template('index.html', skills=skills)

@app.route('/add', methods=['POST'])
def add():
    name = request.form.get('name')
    skill = request.form.get('skill')
    contact = request.form.get('contact')
    if name and skill and contact:
        skills.append({'name': name, 'skill': skill, 'contact': contact})
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
